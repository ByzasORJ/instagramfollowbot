<p align="center">
<a href="https://github.com/tahaluindo"><img title="Author" src="https://img.shields.io/badge/Instagram-Followers-red.svg?style=for-the-badge&logo=instagram"></a>
<a href="https://github.com/tahaluindo"><img title="Author" src="https://img.shields.io/badge/SUNTIK-FOLLOWERS-white.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center"> <img src="https://raw.githubusercontent.com/tahaluindo/InstagramFollowers/main/img/IMG_20221225_204915.jpg"/></p>

[CONTOH DEMO DISINI](https://github.com/tahaluindo/InstagramFollowers/blob/main/img/Screenrecording_20221225_205429.mp4)

<p align="center"> <img src="https://raw.githubusercontent.com/tahaluindo/InstagramFollowers/main/img/IMG_20221225_211212.jpg"/></p>

[VERSI NODEJS DISINI](https://github.com/tahaluindo/instagram-unfollowers)

<p align="center"> <img src="https://user-images.githubusercontent.com/94370774/210161215-9f63b065-6bd7-4d82-a411-ed3dc26ce8b5.jpg"/></p>

</details>

<details>
 <summary><b>:hammer_and_wrench:</b>TUTORIAL DISINI</summary>

Follower bot for Instagram:

After you run the program, enter your instagram username and get free Instagram followers. If you run it during 12 hours, you'll get 400 followers! No need to enter your password to the system. PS: You have to public profile to get free followers. 

## Vitur BOT

https://user-images.githubusercontent.com/94370774/209472156-d9f5d5d8-97b7-44cb-abaa-3e591960fa26.mp4

| Name             | Status              |
| ----------------- | ------------------------- |
| Auto Bypass Captcha | ✅ |
| Suntik Followers | ✅ |
| Suntik Like | ✅ |
| Suntik UnFollowers | ✅ |
| Crack Instagram | ✅ |
| Spam OTP | ✅ |
| Crack Facebook | ✅ |


## Cara Mendapatkan Cookies FB

1. Install Kiwi Browser [DISINI](https://kiwi-browser.id.uptodown.com/android).
2. Setelah Install Pencet Ini [CLICK](chrome://extensions/)
3. Install Ini Get Cookies [DISINI](https://chrome.google.com/webstore/detail/get-token-cookie/naciaagbkifhpnoodlkhbejjldaiffcm)
4. Need Proxy? [CLICK ME](https://github.com/tahaluindo/Free-Proxies)

# Installer Script

1.  Go to [TERMUX](https://f-droid.org/en/packages/com.termux/).
2.  Click on `Download`.
3.  Go to [GOOGLE CHROME](https://www.google.com/intl/id_id/chrome/).

```bash
apt install python && git clone https://github.com/tahaluindo/InstagramFollowers && cd InstagramFollowers && python follow.py
```

- apt-get install python
- git clone https://github.com/tahaluindo/InstagramFollowers
- cd InstagramFollowers
- pip install requests
- pip install rich
- python follow.py

# Warning Tools

- kalian juga bisa pindah tools dengan ketik berikut
- python facebook.py : untuk tools facebook gambar nomor 2 😅
- python crack.py : untuk akses tools crack instagram dan spam otp
- git pull : untuk update terbaru script saya

# Jika Error Modules Installer

```bash
pip install -r requirements.txt
```

- After you run the program, enter your instagram post URL and get free Instagram likes. If you run it during 1 day, you'll get 1570 likes! No need to enter your password to the system. PS: You have to public profile to get free likes.

# Get Credit

- I wrote a bot program for websites that the more credits you earn, the more followers and likes you can gain. The bot helps you earn credits by going to the relevant website and watching videos in the background. In order to convert these credits into followers or likes, you need to go to the website manually from your browser and make the definitions.

# Note For Edit Windows Or Ubuntu

https://github.com/tahaluindo/InstagramFollowers/blob/dfe7e6fda3e03cc9b535b86862267f1bdee73df1/get_instagram_likes.py#L3

# Remarks

When you get expiration error on get_instagram_followers.py or get_instagram_likes.py programs, please change your Instagram username and start the bot again.

Although you change your username and still get expiration error, please try VPN and start the bot again. For example: Hotspot Shield Free VPN program.

## Donasi
<a href="https://saweria.co/anonsecteam" target="_blank"><img src="https://user-images.githubusercontent.com/26188697/180601310-e82c63e4-412b-4c36-b7b5-7ba713c80380.png" alt="Donate For Tahaluindo" height="41" width="174"></a>
